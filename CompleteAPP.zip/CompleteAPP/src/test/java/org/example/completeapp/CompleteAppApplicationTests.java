package org.example.completeapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompleteAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
